﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLib
{
    public class CircleFigure : EllipseFigure
    {
        public int Radius { get; set; }

        public CircleFigure(int x, int y, int radius) : base(x, y, radius, radius)
        {
            this.Radius = radius;
        }

        public CircleFigure() : this(0, 0, 0) { }

        public override void Resize(int radiusWidth, int radiusHeight)
        {
            
            base.Resize(radiusWidth, radiusWidth);
            this.Radius = radiusWidth;
        }

        public override bool Contains(int x, int y)
        {
            
            return (x >= this.x && x <= this.x + this.Radius * 2 && y >= this.y && y <= this.y + this.Radius * 2);
        }
    }
}
