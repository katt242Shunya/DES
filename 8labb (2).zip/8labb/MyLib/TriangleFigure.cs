﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Reflection;

namespace MyLib
{
    public class TriangleFigure : PolygonFigure
    {
        public TriangleFigure(PointF p1, PointF p2, PointF p3) : base(new PointF[] { p1, p2, p3 })
        {
        }

        public override void Draw(Graphics g)
        {
            Color fillColor = IsSelected ? Color.Green : Color.Yellow;

            using (SolidBrush brush = new SolidBrush(fillColor))
            {
                g.FillPolygon(brush, points);
            }

            g.DrawPolygon(new Pen(Color.Black), points);
        }
        public TriangleFigure() : this(new PointF(0, 0), new PointF(0, 0), new PointF(0, 0)) { }
    }
}