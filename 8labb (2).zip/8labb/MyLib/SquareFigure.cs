﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLib
{
    public class SquareFigure : RectangleFigure
    {
        public int side { get; set; } 
        public SquareFigure(int x, int y, int side) : base(x, y, side, side)
        {
        }

        public SquareFigure() : this(0, 0, 0) 
        { 
        }

        public override void Resize(int side, int h) 
        {
            base.Resize(side, side);
        }


    }
}
