﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLib
{
    public class ChristmasTreeFigure : FigureClass
    {
        private PointF location;        
        private int trunkWidth;        
        private int trunkHeight;      
        private int triangleBaseWidth;  
        private int triangleHeight;    
        private int circleRadius;       

        
        public ChristmasTreeFigure(PointF location, int trunkWidth, int trunkHeight, int triangleBaseWidth, int triangleHeight, int circleRadius)
        {
            this.x = (int)location.X;  
            this.y = (int)location.Y;  
            this.location = location; 
            this.trunkWidth = trunkWidth;
            this.trunkHeight = trunkHeight;
            this.triangleBaseWidth = triangleBaseWidth;
            this.triangleHeight = triangleHeight;
            this.circleRadius = circleRadius;
        }

        public int TrunkWidth { get { return trunkWidth; } }
        public int TrunkHeight { get { return trunkHeight; } }
        public int TriangleBaseWidth { get { return triangleBaseWidth; } }
        public int TriangleHeight { get { return triangleHeight; } }
        public int CircleRadius { get { return circleRadius; } }
        public PointF Location { get { return location; } set { location = value; } }

      
        public override void Draw(Graphics g)
        {
            Color fillColor = IsSelected ? Color.Red : Color.Yellow; 

            using (SolidBrush circleBrush = new SolidBrush(Color.Red)) 
            {
                g.FillEllipse(circleBrush, location.X + trunkWidth / 2 - circleRadius, location.Y - triangleHeight * 4 - circleRadius * 2, circleRadius * 2, circleRadius * 2);
            }

            PointF currentTriangleTop = new PointF(location.X + trunkWidth / 2 - triangleBaseWidth / 2, location.Y - triangleHeight * 4);
            for (int i = 0; i < 4; i++)
            {
                PointF p1 = new PointF(currentTriangleTop.X + triangleBaseWidth / 2, currentTriangleTop.Y);
                PointF p2 = new PointF(currentTriangleTop.X, currentTriangleTop.Y + triangleHeight);
                PointF p3 = new PointF(currentTriangleTop.X + triangleBaseWidth, currentTriangleTop.Y + triangleHeight);

                using (SolidBrush brush = new SolidBrush(fillColor))
                {
                    PointF[] points = { p1, p2, p3 };
                    g.FillPolygon(brush, points);
                }

                currentTriangleTop.Y += triangleHeight; 
            }

            using (SolidBrush brownBrush = new SolidBrush(Color.Brown))
            {
                g.FillRectangle(brownBrush, location.X, location.Y, trunkWidth, trunkHeight);
            }
        }

        public override bool Contains(int x, int y)
        {
            if (x >= location.X && x <= location.X + trunkWidth &&
                y >= location.Y && y <= location.Y + trunkHeight)
            {
                return true; 
            }

            PointF currentTriangleTop = new PointF(location.X + trunkWidth / 2 - triangleBaseWidth / 2, location.Y - triangleHeight * 4);
            for (int i = 0; i < 4; i++)
            {
                PointF p1 = new PointF(currentTriangleTop.X + triangleBaseWidth / 2, currentTriangleTop.Y);
                PointF p2 = new PointF(currentTriangleTop.X, currentTriangleTop.Y + triangleHeight);
                PointF p3 = new PointF(currentTriangleTop.X + triangleBaseWidth, currentTriangleTop.Y + triangleHeight);
                PolygonFigure triangle = new PolygonFigure(new PointF[] { p1, p2, p3 }); 
                if (triangle.Contains(x, y))
                    return true;

                currentTriangleTop.Y += triangleHeight; 
            }

            float distance = (float)Math.Sqrt(Math.Pow(x - (location.X + trunkWidth / 2), 2) + Math.Pow(y - (location.Y - triangleHeight * 4 - circleRadius), 2));
            if (distance <= circleRadius)
            {
                return true; 
            }

            return false; 
        }

        public override void MoveTo(int newX, int newY)
        {
            int deltaX = newX - this.x;
            int deltaY = newY - this.y;
            location.X += deltaX;
            location.Y += deltaY;
            this.x = newX;
            this.y = newY;
        }

        public override void Resize(int newWidth, int newHeight)
        {
            
        }
    }
}
