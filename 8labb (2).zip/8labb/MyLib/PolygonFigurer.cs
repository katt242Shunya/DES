﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLib
{
    public class PolygonFigure : FigureClass
    {
        public PointF[] points;

        public PolygonFigure(PointF[] points)
        {
            this.points = points;
            this.x = (int)points[0].X;
            this.y = (int)points[0].Y;
            this.IsSelected = false;  
        }

        public override void Draw(Graphics g)
        {
            Color fillColor = IsSelected ? Color.Green : Color.Yellow; 

            using (SolidBrush brush = new SolidBrush(fillColor))
            {
                g.FillPolygon(brush, points);
            }

            g.DrawPolygon(new Pen(Color.Black), points);
        }

        public override bool Contains(int x, int y)
        {
            bool result = false;
            int j = points.Length - 1;
            for (int i = 0; i < points.Length; i++)
            {
                if (points[i].Y < y && points[j].Y >= y || points[j].Y < y && points[i].Y >= y)
                {
                    if (points[i].X + (y - points[i].Y) / (points[j].Y - points[i].Y) * (points[j].X - points[i].X) < x)
                    {
                        result = !result;
                    }
                }
                j = i;
            }
            return result;
        }

        public override void MoveTo(int newX, int newY)
        {
            int deltaX = newX - this.x;
            int deltaY = newY - this.y;

            for (int i = 0; i < points.Length; i++)
            {
                points[i].X += deltaX;
                points[i].Y += deltaY;
            }

            this.x = newX;
            this.y = newY;
        }

        public override void Resize(int newWidth, int newHeight)
        {
        }
    }
}
