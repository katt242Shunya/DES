﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyLib
{
    public class EllipseFigure : FigureClass
    {
        public int RadiusWidth { get; set; }
        public int RadiusHeight { get; set; }

        public EllipseFigure(int x, int y, int radiusWidth, int radiusHeight)
        {
            this.x = x;
            this.y = y;
            this.RadiusWidth = radiusWidth;
            this.RadiusHeight = radiusHeight;
            IsSelected = false;
        }

        public EllipseFigure() : this(0, 0, 0, 0) { }

        public override void Draw(Graphics g)
        {
           
            Color fillColor = IsSelected ? Color.Green : Color.Yellow;

            using (SolidBrush brush = new SolidBrush(fillColor))
            {
                g.FillEllipse(brush, this.x, this.y, this.RadiusWidth * 2, this.RadiusHeight * 2);
            }
            
            g.DrawEllipse(new Pen(Color.Black), this.x, this.y, this.RadiusWidth * 2, this.RadiusHeight * 2);
        }



        public override void MoveTo(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public override void Resize(int radiusWidth, int radiusHeight)
        {
            this.RadiusWidth = radiusWidth;
            this.RadiusHeight = radiusHeight;
        }

        public override bool Contains(int x, int y)
        {
           
            return (x >= this.x && x <= this.x + this.RadiusWidth * 2 && y >= this.y && y <= this.y + this.RadiusHeight * 2);
        }
    }
}
